﻿namespace Calculatrice
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.label_resultat = new System.Windows.Forms.Label();
            this.label_stock = new System.Windows.Forms.Label();
            this.button_mult = new System.Windows.Forms.Button();
            this.button_moins = new System.Windows.Forms.Button();
            this.button_plus = new System.Windows.Forms.Button();
            this.button0 = new System.Windows.Forms.Button();
            this.button_div = new System.Windows.Forms.Button();
            this.button_EXE = new System.Windows.Forms.Button();
            this.button_virgule = new System.Windows.Forms.Button();
            this.label_operateur = new System.Windows.Forms.Label();
            this.button_mod = new System.Windows.Forms.Button();
            this.Box_stock = new System.Windows.Forms.RichTextBox();
            this.button_sin = new System.Windows.Forms.Button();
            this.button_tan = new System.Windows.Forms.Button();
            this.button_pow = new System.Windows.Forms.Button();
            this.button_facto = new System.Windows.Forms.Button();
            this.button_cos = new System.Windows.Forms.Button();
            this.button_sqrt = new System.Windows.Forms.Button();
            this.comboBox = new System.Windows.Forms.ComboBox();
            this.button_CLEAR = new System.Windows.Forms.Button();
            this.button_DEL = new System.Windows.Forms.Button();
            this.button_ANS = new System.Windows.Forms.Button();
            this.buttonRadToDeg = new System.Windows.Forms.Button();
            this.buttonDegToRad = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.Box_resultat = new System.Windows.Forms.RichTextBox();
            this.Box_operateur = new System.Windows.Forms.RichTextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.button_pi = new System.Windows.Forms.Button();
            this.button_sexy = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(254, 119);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(40, 31);
            this.button1.TabIndex = 0;
            this.button1.Text = "1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(300, 119);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(40, 31);
            this.button2.TabIndex = 1;
            this.button2.Text = "2";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(346, 119);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(40, 31);
            this.button3.TabIndex = 2;
            this.button3.Text = "3";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(254, 82);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(40, 31);
            this.button4.TabIndex = 3;
            this.button4.Text = "4";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(300, 82);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(40, 31);
            this.button5.TabIndex = 4;
            this.button5.Text = "5";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(346, 82);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(40, 31);
            this.button6.TabIndex = 5;
            this.button6.Text = "6";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(254, 45);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(40, 31);
            this.button7.TabIndex = 6;
            this.button7.Text = "7";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(300, 45);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(40, 31);
            this.button8.TabIndex = 7;
            this.button8.Text = "8";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(346, 45);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(40, 31);
            this.button9.TabIndex = 8;
            this.button9.Text = "9";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // label_resultat
            // 
            this.label_resultat.AutoSize = true;
            this.label_resultat.Location = new System.Drawing.Point(52, 27);
            this.label_resultat.Name = "label_resultat";
            this.label_resultat.Size = new System.Drawing.Size(0, 13);
            this.label_resultat.TabIndex = 9;
            // 
            // label_stock
            // 
            this.label_stock.AutoSize = true;
            this.label_stock.Location = new System.Drawing.Point(52, -11);
            this.label_stock.Name = "label_stock";
            this.label_stock.Size = new System.Drawing.Size(0, 13);
            this.label_stock.TabIndex = 10;
            // 
            // button_mult
            // 
            this.button_mult.Location = new System.Drawing.Point(392, 82);
            this.button_mult.Name = "button_mult";
            this.button_mult.Size = new System.Drawing.Size(40, 31);
            this.button_mult.TabIndex = 11;
            this.button_mult.Text = "*";
            this.button_mult.UseVisualStyleBackColor = true;
            this.button_mult.Click += new System.EventHandler(this.button_mult_Click);
            // 
            // button_moins
            // 
            this.button_moins.Location = new System.Drawing.Point(392, 119);
            this.button_moins.Name = "button_moins";
            this.button_moins.Size = new System.Drawing.Size(40, 31);
            this.button_moins.TabIndex = 12;
            this.button_moins.Text = "-";
            this.button_moins.UseVisualStyleBackColor = true;
            this.button_moins.Click += new System.EventHandler(this.button_moins_Click);
            // 
            // button_plus
            // 
            this.button_plus.Location = new System.Drawing.Point(392, 156);
            this.button_plus.Name = "button_plus";
            this.button_plus.Size = new System.Drawing.Size(40, 31);
            this.button_plus.TabIndex = 13;
            this.button_plus.Text = "+";
            this.button_plus.UseVisualStyleBackColor = true;
            this.button_plus.Click += new System.EventHandler(this.button_plus_Click);
            // 
            // button0
            // 
            this.button0.Location = new System.Drawing.Point(254, 156);
            this.button0.Name = "button0";
            this.button0.Size = new System.Drawing.Size(86, 31);
            this.button0.TabIndex = 14;
            this.button0.Text = "0";
            this.button0.UseVisualStyleBackColor = true;
            this.button0.Click += new System.EventHandler(this.button0_Click);
            // 
            // button_div
            // 
            this.button_div.Location = new System.Drawing.Point(392, 45);
            this.button_div.Name = "button_div";
            this.button_div.Size = new System.Drawing.Size(40, 31);
            this.button_div.TabIndex = 15;
            this.button_div.Text = "/";
            this.button_div.UseVisualStyleBackColor = true;
            this.button_div.Click += new System.EventHandler(this.button_div_Click);
            // 
            // button_EXE
            // 
            this.button_EXE.Location = new System.Drawing.Point(438, 119);
            this.button_EXE.Name = "button_EXE";
            this.button_EXE.Size = new System.Drawing.Size(75, 68);
            this.button_EXE.TabIndex = 16;
            this.button_EXE.Text = "EXE";
            this.button_EXE.UseVisualStyleBackColor = true;
            this.button_EXE.Click += new System.EventHandler(this.button_EXE_Click);
            // 
            // button_virgule
            // 
            this.button_virgule.Location = new System.Drawing.Point(346, 156);
            this.button_virgule.Name = "button_virgule";
            this.button_virgule.Size = new System.Drawing.Size(40, 31);
            this.button_virgule.TabIndex = 17;
            this.button_virgule.Text = ",";
            this.button_virgule.UseVisualStyleBackColor = true;
            this.button_virgule.Click += new System.EventHandler(this.button_virgule_Click);
            // 
            // label_operateur
            // 
            this.label_operateur.AutoSize = true;
            this.label_operateur.Location = new System.Drawing.Point(12, 21);
            this.label_operateur.Name = "label_operateur";
            this.label_operateur.Size = new System.Drawing.Size(0, 13);
            this.label_operateur.TabIndex = 18;
            // 
            // button_mod
            // 
            this.button_mod.Location = new System.Drawing.Point(162, 156);
            this.button_mod.Name = "button_mod";
            this.button_mod.Size = new System.Drawing.Size(40, 31);
            this.button_mod.TabIndex = 19;
            this.button_mod.Text = "mod";
            this.button_mod.UseVisualStyleBackColor = true;
            this.button_mod.Click += new System.EventHandler(this.button_mod_Click);
            // 
            // Box_stock
            // 
            this.Box_stock.Location = new System.Drawing.Point(55, 14);
            this.Box_stock.Name = "Box_stock";
            this.Box_stock.Size = new System.Drawing.Size(132, 31);
            this.Box_stock.TabIndex = 20;
            this.Box_stock.Text = "";
            // 
            // button_sin
            // 
            this.button_sin.Location = new System.Drawing.Point(116, 82);
            this.button_sin.Name = "button_sin";
            this.button_sin.Size = new System.Drawing.Size(40, 31);
            this.button_sin.TabIndex = 21;
            this.button_sin.Text = "sin";
            this.button_sin.UseVisualStyleBackColor = true;
            this.button_sin.Click += new System.EventHandler(this.button_sin_Click);
            // 
            // button_tan
            // 
            this.button_tan.Location = new System.Drawing.Point(116, 119);
            this.button_tan.Name = "button_tan";
            this.button_tan.Size = new System.Drawing.Size(40, 31);
            this.button_tan.TabIndex = 23;
            this.button_tan.Text = "tan";
            this.button_tan.UseVisualStyleBackColor = true;
            this.button_tan.Click += new System.EventHandler(this.button_tan_Click);
            // 
            // button_pow
            // 
            this.button_pow.Location = new System.Drawing.Point(162, 119);
            this.button_pow.Name = "button_pow";
            this.button_pow.Size = new System.Drawing.Size(40, 31);
            this.button_pow.TabIndex = 24;
            this.button_pow.Text = "^";
            this.button_pow.UseVisualStyleBackColor = true;
            this.button_pow.Click += new System.EventHandler(this.button_pow_Click);
            // 
            // button_facto
            // 
            this.button_facto.Location = new System.Drawing.Point(208, 156);
            this.button_facto.Name = "button_facto";
            this.button_facto.Size = new System.Drawing.Size(40, 31);
            this.button_facto.TabIndex = 25;
            this.button_facto.Text = "n!";
            this.button_facto.UseVisualStyleBackColor = true;
            this.button_facto.Click += new System.EventHandler(this.button_facto_Click);
            // 
            // button_cos
            // 
            this.button_cos.Location = new System.Drawing.Point(116, 45);
            this.button_cos.Name = "button_cos";
            this.button_cos.Size = new System.Drawing.Size(40, 31);
            this.button_cos.TabIndex = 26;
            this.button_cos.Text = "cos";
            this.button_cos.UseVisualStyleBackColor = true;
            this.button_cos.Click += new System.EventHandler(this.button_cos_Click);
            // 
            // button_sqrt
            // 
            this.button_sqrt.Location = new System.Drawing.Point(208, 119);
            this.button_sqrt.Name = "button_sqrt";
            this.button_sqrt.Size = new System.Drawing.Size(40, 31);
            this.button_sqrt.TabIndex = 27;
            this.button_sqrt.Text = "√";
            this.button_sqrt.UseVisualStyleBackColor = true;
            this.button_sqrt.Click += new System.EventHandler(this.button_sqrt_Click);
            // 
            // comboBox
            // 
            this.comboBox.FormattingEnabled = true;
            this.comboBox.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5"});
            this.comboBox.Location = new System.Drawing.Point(116, 156);
            this.comboBox.Name = "comboBox";
            this.comboBox.Size = new System.Drawing.Size(40, 21);
            this.comboBox.TabIndex = 37;
            // 
            // button_CLEAR
            // 
            this.button_CLEAR.Location = new System.Drawing.Point(438, 45);
            this.button_CLEAR.Name = "button_CLEAR";
            this.button_CLEAR.Size = new System.Drawing.Size(75, 31);
            this.button_CLEAR.TabIndex = 38;
            this.button_CLEAR.Text = "CLEAR";
            this.button_CLEAR.UseVisualStyleBackColor = true;
            this.button_CLEAR.Click += new System.EventHandler(this.button_CLEAR_Click);
            // 
            // button_DEL
            // 
            this.button_DEL.Location = new System.Drawing.Point(438, 82);
            this.button_DEL.Name = "button_DEL";
            this.button_DEL.Size = new System.Drawing.Size(75, 31);
            this.button_DEL.TabIndex = 39;
            this.button_DEL.Text = "DEL";
            this.button_DEL.UseVisualStyleBackColor = true;
            this.button_DEL.Click += new System.EventHandler(this.button_DEL_Click);
            // 
            // button_ANS
            // 
            this.button_ANS.Location = new System.Drawing.Point(438, 8);
            this.button_ANS.Name = "button_ANS";
            this.button_ANS.Size = new System.Drawing.Size(75, 31);
            this.button_ANS.TabIndex = 40;
            this.button_ANS.Text = "ANS";
            this.button_ANS.UseVisualStyleBackColor = true;
            this.button_ANS.Click += new System.EventHandler(this.button_ANS_Click);
            // 
            // buttonRadToDeg
            // 
            this.buttonRadToDeg.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonRadToDeg.Location = new System.Drawing.Point(162, 45);
            this.buttonRadToDeg.Name = "buttonRadToDeg";
            this.buttonRadToDeg.Size = new System.Drawing.Size(86, 31);
            this.buttonRadToDeg.TabIndex = 41;
            this.buttonRadToDeg.Text = "Rad to Deg";
            this.buttonRadToDeg.UseVisualStyleBackColor = true;
            this.buttonRadToDeg.Click += new System.EventHandler(this.buttonRadToDeg_Click);
            // 
            // buttonDegToRad
            // 
            this.buttonDegToRad.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonDegToRad.Location = new System.Drawing.Point(162, 82);
            this.buttonDegToRad.Name = "buttonDegToRad";
            this.buttonDegToRad.Size = new System.Drawing.Size(86, 31);
            this.buttonDegToRad.TabIndex = 42;
            this.buttonDegToRad.Text = "Deg to Rad";
            this.buttonDegToRad.UseVisualStyleBackColor = true;
            this.buttonDegToRad.Click += new System.EventHandler(this.buttonDegToRad_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 159);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(104, 13);
            this.label1.TabIndex = 43;
            this.label1.Text = "Nb après la virgule : ";
            // 
            // Box_resultat
            // 
            this.Box_resultat.Location = new System.Drawing.Point(55, 51);
            this.Box_resultat.Name = "Box_resultat";
            this.Box_resultat.Size = new System.Drawing.Size(55, 31);
            this.Box_resultat.TabIndex = 44;
            this.Box_resultat.Text = "";
            // 
            // Box_operateur
            // 
            this.Box_operateur.Location = new System.Drawing.Point(6, 14);
            this.Box_operateur.Name = "Box_operateur";
            this.Box_operateur.Size = new System.Drawing.Size(40, 31);
            this.Box_operateur.TabIndex = 45;
            this.Box_operateur.Text = "";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(-3, 63);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 13);
            this.label2.TabIndex = 46;
            this.label2.Text = "Resultat : ";
            // 
            // button_pi
            // 
            this.button_pi.Location = new System.Drawing.Point(392, 8);
            this.button_pi.Name = "button_pi";
            this.button_pi.Size = new System.Drawing.Size(40, 31);
            this.button_pi.TabIndex = 47;
            this.button_pi.Text = "π";
            this.button_pi.UseVisualStyleBackColor = true;
            this.button_pi.Click += new System.EventHandler(this.button_pi_Click);
            // 
            // button_sexy
            // 
            this.button_sexy.Location = new System.Drawing.Point(346, 8);
            this.button_sexy.Name = "button_sexy";
            this.button_sexy.Size = new System.Drawing.Size(40, 31);
            this.button_sexy.TabIndex = 48;
            this.button_sexy.Text = "sexy";
            this.button_sexy.UseVisualStyleBackColor = true;
            this.button_sexy.Click += new System.EventHandler(this.button_sexy_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(525, 199);
            this.Controls.Add(this.button_sexy);
            this.Controls.Add(this.button_pi);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Box_operateur);
            this.Controls.Add(this.Box_resultat);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.buttonDegToRad);
            this.Controls.Add(this.buttonRadToDeg);
            this.Controls.Add(this.button_ANS);
            this.Controls.Add(this.button_DEL);
            this.Controls.Add(this.button_CLEAR);
            this.Controls.Add(this.comboBox);
            this.Controls.Add(this.button_sqrt);
            this.Controls.Add(this.button_cos);
            this.Controls.Add(this.button_facto);
            this.Controls.Add(this.button_pow);
            this.Controls.Add(this.button_tan);
            this.Controls.Add(this.button_sin);
            this.Controls.Add(this.Box_stock);
            this.Controls.Add(this.button_mod);
            this.Controls.Add(this.label_operateur);
            this.Controls.Add(this.button_virgule);
            this.Controls.Add(this.button_EXE);
            this.Controls.Add(this.button_div);
            this.Controls.Add(this.button0);
            this.Controls.Add(this.button_plus);
            this.Controls.Add(this.button_moins);
            this.Controls.Add(this.button_mult);
            this.Controls.Add(this.label_stock);
            this.Controls.Add(this.label_resultat);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Label label_resultat;
        private System.Windows.Forms.Label label_stock;
        private System.Windows.Forms.Button button_mult;
        private System.Windows.Forms.Button button_moins;
        private System.Windows.Forms.Button button_plus;
        private System.Windows.Forms.Button button0;
        private System.Windows.Forms.Button button_div;
        private System.Windows.Forms.Button button_EXE;
        private System.Windows.Forms.Button button_virgule;
        private System.Windows.Forms.Label label_operateur;
        private System.Windows.Forms.Button button_mod;
        private System.Windows.Forms.RichTextBox Box_stock;
        private System.Windows.Forms.Button button_sin;
        private System.Windows.Forms.Button button_tan;
        private System.Windows.Forms.Button button_pow;
        private System.Windows.Forms.Button button_facto;
        private System.Windows.Forms.Button button_cos;
        private System.Windows.Forms.Button button_sqrt;
        private System.Windows.Forms.ComboBox comboBox;
        private System.Windows.Forms.Button button_CLEAR;
        private System.Windows.Forms.Button button_DEL;
        private System.Windows.Forms.Button button_ANS;
        private System.Windows.Forms.Button buttonRadToDeg;
        private System.Windows.Forms.Button buttonDegToRad;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RichTextBox Box_resultat;
        private System.Windows.Forms.RichTextBox Box_operateur;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button_pi;
        private System.Windows.Forms.Button button_sexy;

    }
}

